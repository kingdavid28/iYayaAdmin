// AWS EB compatibility - redirect to main server file
require("./serverSupabase.js");
