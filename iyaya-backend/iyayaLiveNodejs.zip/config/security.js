module.exports = {
  maxLoginAttempts: 5,
  lockTime: 30 * 60 * 1000, // 30 minutes
  resetTokenExpires: 10 * 60 * 1000, // 10 minutes
};
