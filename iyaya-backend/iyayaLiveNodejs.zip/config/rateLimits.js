module.exports = {
  auth: {
    windowMs: 15 * 60 * 1000,
    max: 20,
    message: "Too many attempts, please try again later",
  },
};
