module.exports = {
  NODE_ENV: process.env.NODE_ENV || "development",
  // Other configs...
};
